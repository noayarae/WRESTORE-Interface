<?php if (!defined('APP_NAME')) exit('Direct access to this file is not allowed.');

/**
 * Database parameters.
 */

// Host. Usually 'localhost'.
$mt_dbhost = 'localhost';

// Database name. Don't change this unless you are
// using a different database than specified before.
$mt_dbname = 'mt';

// Username.
$mt_dbuser = 'mt';

// Password.
$mt_dbpass = 'mt';
?>