<?php
	// Default styles.
	$fontfamily = "Arial";
	$fontsize = "11px";
	$fontcolor = "#000000";
	$background = "#ffffff";

	// The toolbar
	$bar_background = "#ffe699";
	$bar_bordercolor = "#000000";
	$bar_height = 30;

	$bar_action_fontfamily = "Arial";
	$bar_action_fontsize = "12px";
	$bar_action_fontcolor = "#000000";
	$bar_action_background = "#ffcc33";
	$bar_action_width = "auto";
/*
	$bar_action_bordercolor = "#ffaa33";
	$bar_action_bordercolorhover = "#ff6633";
*/
	$bar_action_bordercolor = "#777777";
	$bar_action_bordercolorhover = "#ffaa33";

	$bar_info_fontfamily = "Arial";
	$bar_info_fontsize = "12px";
	$bar_info_fontcolor = "#000000";
	$bar_info_width = "auto";

	// Styles for a simple table.
	$tab_fontcolor = "#252525";
	$tab_fontcolorheader = "#663D00";
	$tab_fontcolorheaderhover = "#663D00";
	$tab_headerborder = "#f5b800";
	$tab_highlightsoft = "#ffdd75";
	$tab_highlightstrong = "#f5b800";
?>