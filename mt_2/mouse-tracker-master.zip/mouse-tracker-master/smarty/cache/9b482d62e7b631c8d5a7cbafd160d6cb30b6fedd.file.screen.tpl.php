<?php /* Smarty version Smarty-3.1.16, created on 2014-05-02 21:34:26
         compiled from "/home/cbravo/public_html/mt/smarty/templates/screen.tpl" */ ?>
<?php /*%%SmartyHeaderCode:158062060253640593504171-78166624%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9b482d62e7b631c8d5a7cbafd160d6cb30b6fedd' => 
    array (
      0 => '/home/cbravo/public_html/mt/smarty/templates/screen.tpl',
      1 => 1399066435,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '158062060253640593504171-78166624',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_5364059350daf4_68709936',
  'variables' => 
  array (
    'scsizex' => 0,
    'scsizey' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5364059350daf4_68709936')) {function content_5364059350daf4_68709936($_smarty_tpl) {?><div id='wrapviewport' style='width:<?php echo $_smarty_tpl->tpl_vars['scsizex']->value;?>
px; height:<?php echo $_smarty_tpl->tpl_vars['scsizey']->value;?>
px;'>
	<div id='wrapmouse'>
		<img id='wrapcursor' src='images/wrap/cursor-white.png'/>
		<div id='inmsg'></div>
	</div>
</div><?php }} ?>
